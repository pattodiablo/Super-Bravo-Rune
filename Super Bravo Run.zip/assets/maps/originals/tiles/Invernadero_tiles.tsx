<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Invernadero_tiles" tilewidth="32" tileheight="32" tilecount="450" columns="30">
 <image source="../../../environment/Invernadero_tiles.png" width="960" height="480"/>
 <tile id="31">
  <properties>
   <property name="name" value="coin"/>
  </properties>
 </tile>
 <tile id="91">
  <properties>
   <property name="name" value="speed"/>
  </properties>
 </tile>
 <tile id="151">
  <properties>
   <property name="name" value="invisible"/>
  </properties>
 </tile>
</tileset>
