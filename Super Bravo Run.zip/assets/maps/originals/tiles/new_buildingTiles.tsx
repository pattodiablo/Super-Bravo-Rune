<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="new_buildingTiles" tilewidth="32" tileheight="32" tilecount="345" columns="23">
 <image source="../../../environment/new_buildingTiles.png" width="736" height="480"/>
 <tile id="70">
  <properties>
   <property name="name" value="invisible"/>
  </properties>
 </tile>
 <tile id="72">
  <properties>
   <property name="name" value="speed"/>
  </properties>
 </tile>
 <tile id="74">
  <properties>
   <property name="name" value="coin"/>
  </properties>
 </tile>
</tileset>
