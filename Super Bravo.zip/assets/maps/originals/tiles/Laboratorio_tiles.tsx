<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="Laboratorio_tiles" tilewidth="32" tileheight="32" tilecount="450" columns="30">
 <image source="../../../environment/Laboratorio_tiles.png" width="960" height="480"/>
 <tile id="31">
  <properties>
   <property name="name" value="coin"/>
  </properties>
 </tile>
 <tile id="91">
  <properties>
   <property name="name" value="speed"/>
  </properties>
 </tile>
 <tile id="151">
  <properties>
   <property name="name" value="invisible"/>
  </properties>
 </tile>
 <tile id="297">
  <properties>
   <property name="name" value="acid"/>
  </properties>
 </tile>
</tileset>
