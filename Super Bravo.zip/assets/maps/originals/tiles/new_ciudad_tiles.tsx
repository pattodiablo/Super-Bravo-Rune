<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="new_ciudad_tiles" tilewidth="32" tileheight="32" tilecount="435" columns="29">
 <image source="../../../environment/new_ciudad_tiles.png" width="941" height="480"/>
 <tile id="46">
  <properties>
   <property name="name" value="invisible"/>
  </properties>
 </tile>
 <tile id="48">
  <properties>
   <property name="name" value="speed"/>
  </properties>
 </tile>
 <tile id="50">
  <properties>
   <property name="name" value="coin"/>
  </properties>
 </tile>
 <tile id="88">
  <properties>
   <property name="name" value="invisible"/>
  </properties>
 </tile>
 <tile id="90">
  <properties>
   <property name="name" value="speed"/>
  </properties>
 </tile>
 <tile id="92">
  <properties>
   <property name="name" value="coin"/>
  </properties>
 </tile>
</tileset>
